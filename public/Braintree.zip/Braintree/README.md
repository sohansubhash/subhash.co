### Usage Instructions 
 
```bash 
source bt_code/bin/activate 
./bt_code.py input.txt 
./bt_code.py < input.txt 
./test.py
``` 
### Language and Design
I chose python because of it's scripting capabilities and library support. It's also the language I'm most familiar with so I am a bit biased. 
 
My goal for this challenge was to write very readable and simplistic code. I tried to write modular code as well, incase the program needs to be changed. My input handling function `process` is an exception to this. I heavily relied on the assumptions provided to write a quick and dirty parser. See below for details. 
 
### Implementation
(note `balance` is actually `bal` in the code) 
#### Add
To keep track of all created cards I used a global dictionary `cards`, with cardholder names as keys and `Card` objects as values. The only card information the commands access and modify are `limit`,`Luhn validity`, `balance`. Since a card's `name` and `number` never change, they don't need to be apart of the `Card` object. 
#### Credit/Charge
The Credit and Charge commands could have easily be implemented as a single function, with a boolean flag to indicate addition or subtraction. I chose to separate them for the sake of modularity. I also chose not to place the `Luhn 10 valid` check for Charge and Credit in the `process` function (despite them sharing a logic branch) for the same reasons. 
#### Summary
Even though it was tempting to set an invalid cards `balance` to `"error"` (Since Charge and Credit don't apply) to make printing easier, I chose to keep the code modular. Since the specifications did not specific how many inputs. I decided that the performance gains of implementing a binary search tree for sorting the card holder names were not worth it. I used the built-in `sorted` function.
#### Input Handling
If I had to handle a combination of both STDIN and file reading or a more complex CLI, I would have used the `argparse` library. 
##### The assumptions
- either STDIN or reading from a file -> `fileinput` library to read in 
- Space delimitation -> splice method to get individual words 
- Valid input always -> lack of error handling 
- Fixed number of fields: `Command` `Card Holder Name` `Remaining Arguments` 
- Amounts will have $ -> check for `'$'` to check the command type 
 
Since Credit and Charge both have an amount argument following name, any provided argument following the name without a `'$'` must be an Add. I also put in a check to make sure any calls to Credit or Charge pass in a name for a created card (This could have been in the `credit` or `charge` functions, but was not specified behavior) 
### Testing
I used the `unittest` library to isolate and test each function seperately. 
I accounted for all of the cases detailed in the spec.