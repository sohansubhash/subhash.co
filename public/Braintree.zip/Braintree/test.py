#!/usr/bin/env python
import unittest
import bt_code
from unittest.mock import patch
from contextlib import redirect_stdout
import io

class TestCard(unittest.TestCase):
 
    def setUp(self):
    	pass
        
    def testAdd(self):
        '''
        create a new credit card for a given name, card number, and limit
        card numbers should be validated using Luhn 10
        new cards start with a $0 balance
        card numbers can be less than 19 chars
        '''
        bt_code.cards = {}
        bt_code.add("Tom", "4111111111111111", 1000)
        bt_code.add("Sara", "41111115111", 2000)
        bt_code.add("John", "411111", 2000)
        

        self.assertTrue( "Tom" in bt_code.cards)
        self.assertTrue( "Sara" in bt_code.cards)
        self.assertTrue( "John" in bt_code.cards)

        self.assertFalse( bt_code.cards["Sara"].getValid())
        self.assertTrue( bt_code.cards["Tom"].getValid())
        self.assertFalse( bt_code.cards["John"].getValid())
        

        self.assertEqual( bt_code.cards["Sara"].getBal(), 0)
        self.assertEqual( bt_code.cards["Tom"].getBal(), 0)
        print("Passed Add test!")       
 
    def testCharge(self):
        '''
        increase the balance of the card associated with the provided name by the amount specified
        charges that would raise the balance over the limit are ignored as if they were declined
        charges against Luhn 10 invalid cards are ignored
        '''
        bt_code.cards = {"Tom":bt_code.Card(1000, True), "Sara":bt_code.Card(2000, False)}
        
        bt_code.charge(bt_code.cards["Tom"], 500)
        bt_code.charge(bt_code.cards["Tom"], 800)
        bt_code.charge(bt_code.cards["Sara"], 800)

        self.assertEqual( bt_code.cards["Sara"].getBal(), 0)
        self.assertEqual( bt_code.cards["Tom"].getBal(), 500)
        print("Passed Charge test!")        

    def testCredit(self):
        '''
        will decrease the balance of the card associated with the provided name by the amount specified
        credits that would drop the balance below $0 will create a negative balance
        credits against Luhn 10 invalid cards are ignored
        '''
        bt_code.cards = {"Tom":bt_code.Card(1000, True), "Sara":bt_code.Card(2000, False)}

        bt_code.credit(bt_code.cards["Tom"], 500)
        bt_code.credit(bt_code.cards["Sara"], 500)

        self.assertEqual( bt_code.cards["Sara"].getBal(), 0)
        self.assertEqual( bt_code.cards["Tom"].getBal(), -500)
        print("Passed Credit test!")      
      
    def testSummary(self):
        '''
        should include the name of each person followed by a colon and balance
        The names should be displayed alphabetically
        display "error" instead of the balance if the credit card number does not pass Luhn 10.
        '''
        bt_code.cards = {"Tom":bt_code.Card(1000, True), "Sara":bt_code.Card(2000, False), "Hubert":bt_code.Card(1000, True)}
        
        bt_code.cards["Tom"].bal = 500
        bt_code.cards["Hubert"].bal = 800

        out = io.StringIO()
        with redirect_stdout(out):
            bt_code.summary()
        
     
        self.assertEqual( out.getvalue(), 'Hubert: $800\nSara: error\nTom: $500\n')
        print("Passed Summary test!")     


    @patch('bt_code.add')
    @patch('bt_code.credit')
    @patch('bt_code.charge')
    def testProcess(self, mock_add, mock_credit, mock_charge):
        '''
        should do nothing if card is not in cards and Credit/Charge is called
        should call the appropriate functions
        '''
        bt_code.cards = {"Hubert":bt_code.Card(1000, True)}
        
        line1 = "Add Tom 4111111111111111 $1000"
        line2 = "Credit Hubert $200"
        line3 = "Charge Sara $10"
        line4 = "Charge Hubert $100"

        bt_code.process(line1)
        bt_code.process(line2)
        bt_code.process(line3)
        bt_code.process(line4)

        self.assertTrue(bt_code.add.called)
        self.assertTrue(bt_code.credit.called)
        self.assertTrue(bt_code.charge.called)
        self.assertEqual(bt_code.charge.call_count, 1)

        print("Passed Process test!")


if __name__ == '__main__':
    testc = TestCard()
    testc.testAdd()
    testc.testCharge()
    testc.testCredit()
    testc.testSummary()
    testc.testProcess()

