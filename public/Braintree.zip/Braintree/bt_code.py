#!/usr/bin/env python
import fileinput
from luhn import verify

class Card(object):
    def __init__(self, limit, valid):
        self.limit = limit
        self.bal = 0
        self.valid = valid

    def charge(self, amount):
        self.bal += amount

    def credit(self, amount):
        self.bal -= amount

    def getBal(self):
        return self.bal

    def getLimit(self):
        return self.limit
    
    def getValid(self):
        return self.valid

def add(name, number, limit):
    valid = verify(number)    
    cards[name] = Card(limit, valid)

def charge(card, amount):
    if card.getValid(): 
        if card.getLimit() > card.getBal() + amount:
            card.charge(amount)

def credit(card, amount):
    if card.getValid(): 
        card.credit(amount)

def summary():
    for name in sorted(cards):
        print(name + ': ', end='')
        card = cards[name]
        if(card.getValid()):
            print('$' + str(card.getBal()))
        else:
            print("error")

def process(line):
    args = line.split()
    com = args[0]
    name = args[1]
    if(args[2][0] == '$'): #checks if the second argument is an amount
        if name in cards:
            card = cards[name]
            amount = int(args[2][1:])
            charge(card, amount) if com == "Charge" else credit(card, amount) 
    else:
        limit = int(args[3][1:])
        number = args[2]
        add(name, number, limit)

cards = {}
if __name__ == "__main__":
    for line in fileinput.input():
        process(line)
        
    summary()
